# Watch Shop Template

A Pen created on CodePen.

Original URL: [https://codepen.io/chrisfawson/pen/MWegLNg](https://codepen.io/chrisfawson/pen/MWegLNg).

Watch Shop Template Assignment